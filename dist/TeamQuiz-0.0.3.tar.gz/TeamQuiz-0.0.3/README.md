# competition_api
This is a customisable Fast API app that can be used to host a variety of competitions or quizzes. It can be accessed via API calls or via a pip installed package

The main.py rests on the FastAPI server, it connects to the database and anwers API calls

The oo_package.py file is pip installed locally it simplifies the API calls, provides a CLI interface and prints rankings. It will have the capacity to encrypt sensitive data like the competition answers.

Here is the diagram showing the classes, files and the database


![Diagram](Diagram.png)